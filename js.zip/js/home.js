function toggleMenu() {
  var nav = document.getElementById("nav");
  nav.classList.toggle("open");
}
